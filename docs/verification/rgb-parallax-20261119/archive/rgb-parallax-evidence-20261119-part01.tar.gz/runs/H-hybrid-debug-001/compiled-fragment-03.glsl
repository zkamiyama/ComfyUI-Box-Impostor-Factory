#version 300 es

// Three.js r186 - Node System


// extensions


// precision

precision highp float;
precision highp int;
precision highp sampler2D;
precision highp sampler3D;
precision highp samplerCube;
precision highp sampler2DArray;

precision highp usampler2D;
precision highp usampler3D;
precision highp usamplerCube;
precision highp usampler2DArray;

precision highp isampler2D;
precision highp isampler3D;
precision highp isamplerCube;
precision highp isampler2DArray;

precision highp sampler2DShadow;
precision highp sampler2DArrayShadow;
precision highp samplerCubeShadow;


// structs

layout( location = 0 ) out vec4 fragColor;



// uniforms

layout( std140 ) uniform render {
	float cameraNear;
	float cameraFar;
	mat4 cameraProjectionMatrix;
	mat4 cameraViewMatrix;
	mat4 cameraWorldMatrix;
	vec3 cameraPosition;
};

layout( std140 ) uniform object {
	mat4 nodeUniform1;
	float nodeUniform4;
	uint nodeUniform6;
	uint nodeUniform7;
	uint nodeUniform8;
	uint nodeUniform10;
	uint nodeUniform11;
	uint nodeUniform12;
	uint nodeUniform13;
	uint nodeUniform14;
	uint nodeUniform15;
	uint nodeUniform16;
	uint nodeUniform17;
	uint nodeUniform18;
	uint nodeUniform20;
	uint nodeUniform22;
	uint nodeUniform23;
	uint nodeUniform24;
	uint nodeUniform25;
	uint nodeUniform26;
	uint nodeUniform27;
	uint nodeUniform28;
	uint nodeUniform29;
	uint nodeUniform30;
	uint nodeUniform31;
	uint nodeUniform32;
	uint nodeUniform33;
	uint nodeUniform34;
	uint nodeUniform35;
	uint nodeUniform36;
	uint nodeUniform37;
	uint nodeUniform38;
	uint nodeUniform39;
	uint nodeUniform40;
	uint nodeUniform41;
	uint nodeUniform42;
	uint nodeUniform43;
	uint nodeUniform44;
	uint nodeUniform45;
	uint nodeUniform46;
	uint nodeUniform47;
	uint nodeUniform48;
	uint nodeUniform49;
	uint nodeUniform50;
	vec3 nodeUniform54;
	uint nodeUniform55;
	uint nodeUniform56;
	uint nodeUniform57;
	uint nodeUniform58;
	uint nodeUniform59;
	uint nodeUniform60;
	uint nodeUniform61;
	uint nodeUniform62;
	uint nodeUniform63;
	float nodeUniform64;
	float nodeUniform65;
	float nodeUniform66;
	mat3 nodeUniform67;
};
uniform sampler2D nodeUniform5;
uniform sampler2D nodeUniform9;
uniform sampler2D nodeUniform19;
uniform sampler2D nodeUniform21;

// varyings
in vec3 nodeVarying3;
in vec3 nodeVarying4;
in vec3 nodeVarying5;
in vec3 nodeVarying6;
in vec3 nodeVarying7;
in vec3 nodeVarying8;
in vec3 nodeVarying9;
in vec3 nodeVarying10;
in vec3 nodeVarying11;
in vec3 nodeVarying12;
in vec3 v_normalViewGeometry;


// vars
vec4 DiffuseColor;
vec3 nodeVar0;
bool nodeVar1;
vec3 nodeVar3;
vec3 nodeVar4;
vec3 nodeVar5;
vec3 nodeVar6;
vec3 nodeVar7;
vec3 nodeVar8;
vec3 nodeVar9;
float nodeVar10;
float nodeVar11;
bool nodeVar12;
float nodeVar13;
float nodeVar14;
float nodeVar15;
vec3 nodeVar16;
vec3 nodeVar17;
vec3 nodeVar18;
vec3 nodeVar19;
bool nodeVar20;
vec3 nodeVar21;
vec2 nodeVar22;
vec2 nodeVar23;
vec2 nodeVar24;
vec2 nodeVar25;
bool nodeVar26;
vec2 nodeVar27;
vec4 nodeVar28;
vec3 nodeVar29;
vec2 nodeVar30;
vec2 nodeVar31;
vec2 nodeVar32;
vec2 nodeVar33;
bool nodeVar34;
vec2 nodeVar35;
vec4 nodeVar36;
vec3 nodeVar37;
vec2 nodeVar38;
vec2 nodeVar39;
vec2 nodeVar40;
vec2 nodeVar41;
bool nodeVar42;
vec2 nodeVar43;
vec4 nodeVar44;
vec3 nodeVar45;
bool nodeVar46;
vec2 nodeVar47;
vec2 nodeVar48;
vec2 nodeVar49;
vec2 nodeVar50;
bool nodeVar51;
vec2 nodeVar52;
vec4 nodeVar53;
vec2 nodeVar54;
vec2 nodeVar55;
vec2 nodeVar56;
vec2 nodeVar57;
bool nodeVar58;
vec2 nodeVar59;
vec4 nodeVar60;
vec2 nodeVar61;
vec2 nodeVar62;
vec2 nodeVar63;
vec2 nodeVar64;
bool nodeVar65;
vec2 nodeVar66;
vec4 nodeVar67;
vec3 nodeVar68;
float nodeVar69;
float nodeVar70;
float nodeVar71;
float nodeVar72;
vec3 nodeVar73;
bool nodeVar74;
vec2 nodeVar75;
vec2 nodeVar76;
vec2 nodeVar77;
vec2 nodeVar78;
bool nodeVar79;
vec2 nodeVar80;
vec4 nodeVar81;
vec2 nodeVar82;
vec2 nodeVar83;
vec2 nodeVar84;
vec2 nodeVar85;
bool nodeVar86;
vec2 nodeVar87;
vec4 nodeVar88;
vec2 nodeVar89;
vec2 nodeVar90;
vec2 nodeVar91;
vec2 nodeVar92;
bool nodeVar93;
vec2 nodeVar94;
vec4 nodeVar95;
vec3 nodeVar96;
vec2 nodeVar97;
vec2 nodeVar98;
vec2 nodeVar99;
vec2 nodeVar100;
bool nodeVar101;
vec2 nodeVar102;
vec4 nodeVar103;
float nodeVar104;
float nodeVar105;
vec2 nodeVar106;
vec2 nodeVar107;
vec2 nodeVar108;
vec2 nodeVar109;
bool nodeVar110;
vec2 nodeVar111;
vec4 nodeVar112;
float nodeVar113;
float nodeVar114;
vec2 nodeVar115;
vec2 nodeVar116;
vec2 nodeVar117;
vec2 nodeVar118;
bool nodeVar119;
vec2 nodeVar120;
vec4 nodeVar121;
float nodeVar122;
float nodeVar123;
float nodeVar124;
vec3 nodeVar125;
vec3 nodeVar126;
vec3 nodeVar127;
float nodeVar128;
vec3 nodeVar129;
float nodeVar130;
vec2 nodeVar131;
vec2 nodeVar132;
vec2 nodeVar133;
vec2 nodeVar134;
bool nodeVar135;
vec2 nodeVar136;
vec4 nodeVar137;
vec2 nodeVar138;
vec2 nodeVar139;
bool nodeVar140;
vec2 nodeVar141;
vec4 nodeVar142;
vec3 nodeVar143;
float nodeVar144;
float nodeVar145;
float nodeVar146;
vec3 nodeVar147;
vec2 nodeVar148;
vec2 nodeVar149;
vec2 nodeVar150;
vec2 nodeVar151;
bool nodeVar152;
vec2 nodeVar153;
vec4 nodeVar154;
vec2 nodeVar155;
vec2 nodeVar156;
bool nodeVar157;
vec2 nodeVar158;
vec4 nodeVar159;
vec3 nodeVar160;
float nodeVar161;
float nodeVar162;
float nodeVar163;
vec3 nodeVar164;
vec2 nodeVar165;
vec2 nodeVar166;
vec2 nodeVar167;
vec2 nodeVar168;
bool nodeVar169;
vec2 nodeVar170;
vec4 nodeVar171;
vec2 nodeVar172;
vec2 nodeVar173;
bool nodeVar174;
vec2 nodeVar175;
vec4 nodeVar176;
vec3 nodeVar177;
float nodeVar178;
float nodeVar179;
float nodeVar180;
vec3 nodeVar181;
vec2 nodeVar182;
vec2 nodeVar183;
vec2 nodeVar184;
vec2 nodeVar185;
bool nodeVar186;
vec2 nodeVar187;
vec4 nodeVar188;
vec2 nodeVar189;
vec2 nodeVar190;
bool nodeVar191;
vec2 nodeVar192;
vec4 nodeVar193;
vec3 nodeVar194;
float nodeVar195;
float nodeVar196;
float nodeVar197;
vec3 nodeVar198;
vec2 nodeVar199;
vec2 nodeVar200;
vec2 nodeVar201;
vec2 nodeVar202;
bool nodeVar203;
vec2 nodeVar204;
vec4 nodeVar205;
vec2 nodeVar206;
vec2 nodeVar207;
bool nodeVar208;
vec2 nodeVar209;
vec4 nodeVar210;
vec3 nodeVar211;
float nodeVar212;
float nodeVar213;
float nodeVar214;
vec3 nodeVar215;
vec2 nodeVar216;
vec2 nodeVar217;
vec2 nodeVar218;
vec2 nodeVar219;
bool nodeVar220;
vec2 nodeVar221;
vec4 nodeVar222;
vec2 nodeVar223;
vec2 nodeVar224;
bool nodeVar225;
vec2 nodeVar226;
vec4 nodeVar227;
vec3 nodeVar228;
float nodeVar229;
float nodeVar230;
float nodeVar231;
vec3 nodeVar232;
bool nodeVar233;
vec3 nodeVar234;
vec3 nodeVar235;
vec3 nodeVar236;
vec3 nodeVar237;
vec2 nodeVar238;
vec2 nodeVar239;
vec2 nodeVar240;
vec2 nodeVar241;
bool nodeVar242;
vec2 nodeVar243;
vec4 nodeVar244;
vec2 nodeVar245;
vec2 nodeVar246;
vec2 nodeVar247;
vec2 nodeVar248;
bool nodeVar249;
vec2 nodeVar250;
vec4 nodeVar251;
vec2 nodeVar252;
vec2 nodeVar253;
vec2 nodeVar254;
vec2 nodeVar255;
bool nodeVar256;
vec2 nodeVar257;
vec4 nodeVar258;
vec3 nodeVar259;
vec2 nodeVar260;
vec2 nodeVar261;
vec2 nodeVar262;
vec2 nodeVar263;
bool nodeVar264;
vec2 nodeVar265;
vec4 nodeVar266;
vec2 nodeVar267;
vec2 nodeVar268;
vec2 nodeVar269;
vec2 nodeVar270;
bool nodeVar271;
vec2 nodeVar272;
vec4 nodeVar273;
vec2 nodeVar274;
vec2 nodeVar275;
vec2 nodeVar276;
vec2 nodeVar277;
bool nodeVar278;
vec2 nodeVar279;
vec4 nodeVar280;
vec3 nodeVar281;
vec2 nodeVar282;
vec2 nodeVar283;
vec2 nodeVar284;
vec2 nodeVar285;
bool nodeVar286;
vec2 nodeVar287;
vec4 nodeVar288;
vec2 nodeVar289;
vec2 nodeVar290;
vec2 nodeVar291;
vec2 nodeVar292;
bool nodeVar293;
vec2 nodeVar294;
vec4 nodeVar295;
vec2 nodeVar296;
vec2 nodeVar297;
vec2 nodeVar298;
vec2 nodeVar299;
bool nodeVar300;
vec2 nodeVar301;
vec4 nodeVar302;
vec3 nodeVar303;
vec2 nodeVar304;
vec2 nodeVar305;
vec2 nodeVar306;
vec2 nodeVar307;
bool nodeVar308;
vec2 nodeVar309;
vec4 nodeVar310;
vec2 nodeVar311;
vec2 nodeVar312;
vec2 nodeVar313;
vec2 nodeVar314;
bool nodeVar315;
vec2 nodeVar316;
vec4 nodeVar317;
vec2 nodeVar318;
vec2 nodeVar319;
vec2 nodeVar320;
vec2 nodeVar321;
bool nodeVar322;
vec2 nodeVar323;
vec4 nodeVar324;
vec3 nodeVar325;
vec2 nodeVar326;
vec2 nodeVar327;
vec2 nodeVar328;
vec2 nodeVar329;
bool nodeVar330;
vec2 nodeVar331;
vec4 nodeVar332;
vec2 nodeVar333;
vec2 nodeVar334;
vec2 nodeVar335;
vec2 nodeVar336;
bool nodeVar337;
vec2 nodeVar338;
vec4 nodeVar339;
vec2 nodeVar340;
vec2 nodeVar341;
vec2 nodeVar342;
vec2 nodeVar343;
bool nodeVar344;
vec2 nodeVar345;
vec4 nodeVar346;
vec3 nodeVar347;
vec2 nodeVar348;
vec2 nodeVar349;
vec2 nodeVar350;
vec2 nodeVar351;
bool nodeVar352;
vec2 nodeVar353;
vec4 nodeVar354;
vec2 nodeVar355;
vec2 nodeVar356;
vec2 nodeVar357;
vec2 nodeVar358;
bool nodeVar359;
vec2 nodeVar360;
vec4 nodeVar361;
vec2 nodeVar362;
vec2 nodeVar363;
vec2 nodeVar364;
vec2 nodeVar365;
bool nodeVar366;
vec2 nodeVar367;
vec4 nodeVar368;
vec3 ImpostorNormal;
vec3 ParallaxNativeHitPosition;
vec3 nodeVar371;
vec3 ImpostorPositionView;
float ImpostorDepth;
float nodeVar372;
vec4 nodeVar373;
vec3 nodeVar374;
vec3 nodeVar375;
vec3 nodeVar376;
vec3 nodeVar377;
vec3 nodeVar378;
vec2 nodeVar379;
vec2 nodeVar380;
vec2 nodeVar381;
vec2 nodeVar382;
bool nodeVar383;
vec2 nodeVar384;
vec4 nodeVar385;
float nodeVar386;
float nodeVar387;
vec2 nodeVar388;
vec2 nodeVar389;
vec2 nodeVar390;
vec2 nodeVar391;
bool nodeVar392;
vec2 nodeVar393;
vec4 nodeVar394;
float nodeVar395;
float nodeVar396;
vec2 nodeVar397;
vec2 nodeVar398;
vec2 nodeVar399;
vec2 nodeVar400;
bool nodeVar401;
vec2 nodeVar402;
vec4 nodeVar403;
float nodeVar404;
float nodeVar405;
vec2 nodeVar406;
vec2 nodeVar407;
vec2 nodeVar408;
vec2 nodeVar409;
bool nodeVar410;
vec2 nodeVar411;
vec4 nodeVar412;
vec4 nodeVar413;
float nodeVar414;
vec2 nodeVar415;
vec2 nodeVar416;
vec2 nodeVar417;
vec2 nodeVar418;
bool nodeVar419;
vec2 nodeVar420;
vec4 nodeVar421;
vec4 nodeVar422;
float nodeVar423;
vec2 nodeVar424;
vec2 nodeVar425;
vec2 nodeVar426;
vec2 nodeVar427;
bool nodeVar428;
vec2 nodeVar429;
vec4 nodeVar430;
vec4 nodeVar431;
float nodeVar432;
vec2 nodeVar433;
vec2 nodeVar434;
vec2 nodeVar435;
vec2 nodeVar436;
bool nodeVar437;
vec2 nodeVar438;
vec4 nodeVar439;
vec4 nodeVar440;
float nodeVar441;
vec2 nodeVar442;
vec2 nodeVar443;
vec2 nodeVar444;
vec2 nodeVar445;
bool nodeVar446;
vec2 nodeVar447;
vec4 nodeVar448;
vec4 nodeVar449;
float nodeVar450;
vec2 nodeVar451;
vec2 nodeVar452;
vec2 nodeVar453;
vec2 nodeVar454;
bool nodeVar455;
vec2 nodeVar456;
vec4 nodeVar457;
vec4 nodeVar458;
float nodeVar459;
vec3 nodeVar460;
float nodeVar461;
float nodeVar462;
vec3 nodeVar463;
float nodeVar464;
float nodeVar465;
float nodeVar466;
float nodeVar467;
float nodeVar468;
float nodeVar469;
float nodeVar470;
vec3 nodeVar471;
float Metalness;
float Roughness;
vec3 normalViewGeometry;
vec3 nodeVar472;
vec3 SpecularColor;
vec3 SpecularColorBlended;
float SpecularF90;
vec3 DiffuseContribution;
vec4 Output;
vec4 nodeVar473;

// codes


void main() {

	// flow
	// code

	nodeVar1 = ( cameraProjectionMatrix[ 2u ].w == 0.0 );

	if ( nodeVar1 ) {

		nodeVar0 = ( nodeVarying3 - ( nodeVarying4 * vec3( ( length( vec3( 0.40023485660552977, 1.04, 0.3785624587535858 ) ) * 4.0 ) ) ) );

	} else {

		nodeVar0 = nodeVarying5;

	}

	nodeVar3 = nodeVar0;
	nodeVar4 = ( nodeVarying3 - nodeVar3 );
	nodeVar5 = ( ( nodeVar3 - vec3( -0.20011742830276488, -0.52, -0.1892812293767929 ) ) / vec3( 0.40023485660552977, 1.04, 0.3785624587535858 ) );
	nodeVar6 = ( nodeVar4 / vec3( 0.40023485660552977, 1.04, 0.3785624587535858 ) );
	nodeVar7 = ( vec3( 1.0, 1.0, 1.0 ) / nodeVar6 );
	nodeVar8 = ( ( - nodeVar5 ) * nodeVar7 );
	nodeVar9 = ( ( vec3( 1.0 ) - nodeVar5 ) * nodeVar7 );
	nodeVar10 = max( max( min( nodeVar8.x, nodeVar9.x ), min( nodeVar8.y, nodeVar9.y ) ), max( min( nodeVar8.z, nodeVar9.z ), 0.0 ) );
	nodeVar11 = min( min( max( nodeVar8.x, nodeVar9.x ), max( nodeVar8.y, nodeVar9.y ) ), max( nodeVar8.z, nodeVar9.z ) );
	nodeVar12 = false;
	nodeVar13 = nodeVar10;
	nodeVar14 = nodeVar10;
	nodeVar15 = ( 0.00146484375 / length( nodeVar6 ) );

	if ( ( nodeVar11 > nodeVar10 ) ) {


		for ( int i = 0; i < int( nodeUniform4 ); i ++ ) {


			if ( ( nodeVar13 > nodeVar11 ) ) {

				break;
				

			}

			nodeVar16 = ( nodeVar5 + ( nodeVar6 * vec3( nodeVar13 ) ) );
			nodeVar17 = clamp( floor( ( nodeVar16 / vec3( 0.0078125 ) ) ), vec3( 0.0 ), vec3( 127.0 ) );
			nodeVar18 = ( ( nodeVar17 * vec3( 0.0078125 ) ) - vec3( 0.00244140625 ) );
			nodeVar19 = ( ( ( nodeVar17 + vec3( 1.0 ) ) * vec3( 0.0078125 ) ) + vec3( 0.00244140625 ) );
			nodeVar20 = false;
			nodeVar21 = ( ( nodeVar17 + vec3( 0.5 ) ) / vec3( 128.0 ) );
			nodeVar22 = vec2( nodeVar21.z, nodeVar21.y );
			nodeVar23 = ( vec2( ( nodeVar22.x + 0.0 ), nodeVar22.y ) / vec2( 3.0, 1.0 ) );
			nodeVar24 = nodeVar23;
			nodeVar26 = bool( nodeUniform6 );

			if ( nodeVar26 ) {

				nodeVar27 = nodeVar24;
				nodeVar25 = vec2( nodeVar27.x, 1.0 - nodeVar27.y );

			} else {

				nodeVar25 = nodeVar24;

			}

			nodeVar28 = textureLod( nodeUniform5, nodeVar25, 0.0 );

			if ( ( ( nodeVar28.x <= nodeVar19[ 0u ] ) && ( nodeVar28.y >= nodeVar18[ 0u ] ) ) ) {

				nodeVar29 = ( ( nodeVar17 + vec3( 0.5 ) ) / vec3( 128.0 ) );
				nodeVar30 = vec2( nodeVar29.x, nodeVar29.z );
				nodeVar31 = ( vec2( ( nodeVar30.x + 1.0 ), nodeVar30.y ) / vec2( 3.0, 1.0 ) );
				nodeVar32 = nodeVar31;
				nodeVar34 = bool( nodeUniform7 );

				if ( nodeVar34 ) {

					nodeVar35 = nodeVar32;
					nodeVar33 = vec2( nodeVar35.x, 1.0 - nodeVar35.y );

				} else {

					nodeVar33 = nodeVar32;

				}

				nodeVar36 = textureLod( nodeUniform5, nodeVar33, 0.0 );

				if ( ( ( nodeVar36.x <= nodeVar19[ 1u ] ) && ( nodeVar36.y >= nodeVar18[ 1u ] ) ) ) {

					nodeVar37 = ( ( nodeVar17 + vec3( 0.5 ) ) / vec3( 128.0 ) );
					nodeVar38 = vec2( nodeVar37.x, nodeVar37.y );
					nodeVar39 = ( vec2( ( nodeVar38.x + 2.0 ), nodeVar38.y ) / vec2( 3.0, 1.0 ) );
					nodeVar40 = nodeVar39;
					nodeVar42 = bool( nodeUniform8 );

					if ( nodeVar42 ) {

						nodeVar43 = nodeVar40;
						nodeVar41 = vec2( nodeVar43.x, 1.0 - nodeVar43.y );

					} else {

						nodeVar41 = nodeVar40;

					}

					nodeVar44 = textureLod( nodeUniform5, nodeVar41, 0.0 );
					nodeVar20 = ( ( nodeVar44.x <= nodeVar19[ 2u ] ) && ( nodeVar44.y >= nodeVar18[ 2u ] ) );
					

				}

				

			}


			if ( nodeVar20 ) {

				nodeVar45 = nodeVar16;
				nodeVar46 = false;
				nodeVar47 = clamp( vec2( nodeVar45.z, nodeVar45.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
				nodeVar48 = ( vec2( ( nodeVar47.x + 0.0 ), nodeVar47.y ) / vec2( 3.0, 1.0 ) );
				nodeVar49 = nodeVar48;
				nodeVar51 = bool( nodeUniform10 );

				if ( nodeVar51 ) {

					nodeVar52 = nodeVar49;
					nodeVar50 = vec2( nodeVar52.x, 1.0 - nodeVar52.y );

				} else {

					nodeVar50 = nodeVar49;

				}

				nodeVar53 = textureLod( nodeUniform9, nodeVar50, 0.0 );

				if ( ( ( ( nodeVar45.x <= ( nodeVar53.x + 0.00146484375 ) ) && ( nodeVar45.x >= ( ( 1.0 - nodeVar53.y ) - 0.00146484375 ) ) ) && ( ( nodeVar45.x <= ( nodeVar53.w + 0.00146484375 ) ) || ( nodeVar45.x >= ( nodeVar53.z - 0.00146484375 ) ) ) ) ) {

					nodeVar54 = clamp( vec2( nodeVar45.x, nodeVar45.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
					nodeVar55 = ( vec2( ( nodeVar54.x + 1.0 ), nodeVar54.y ) / vec2( 3.0, 1.0 ) );
					nodeVar56 = nodeVar55;
					nodeVar58 = bool( nodeUniform11 );

					if ( nodeVar58 ) {

						nodeVar59 = nodeVar56;
						nodeVar57 = vec2( nodeVar59.x, 1.0 - nodeVar59.y );

					} else {

						nodeVar57 = nodeVar56;

					}

					nodeVar60 = textureLod( nodeUniform9, nodeVar57, 0.0 );

					if ( ( ( ( nodeVar45.y <= ( nodeVar60.x + 0.00146484375 ) ) && ( nodeVar45.y >= ( ( 1.0 - nodeVar60.y ) - 0.00146484375 ) ) ) && ( ( nodeVar45.y <= ( nodeVar60.w + 0.00146484375 ) ) || ( nodeVar45.y >= ( nodeVar60.z - 0.00146484375 ) ) ) ) ) {

						nodeVar61 = clamp( vec2( nodeVar45.x, nodeVar45.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
						nodeVar62 = ( vec2( ( nodeVar61.x + 2.0 ), nodeVar61.y ) / vec2( 3.0, 1.0 ) );
						nodeVar63 = nodeVar62;
						nodeVar65 = bool( nodeUniform12 );

						if ( nodeVar65 ) {

							nodeVar66 = nodeVar63;
							nodeVar64 = vec2( nodeVar66.x, 1.0 - nodeVar66.y );

						} else {

							nodeVar64 = nodeVar63;

						}

						nodeVar67 = textureLod( nodeUniform9, nodeVar64, 0.0 );

						if ( ( ( ( nodeVar45.z <= ( nodeVar67.x + 0.00146484375 ) ) && ( nodeVar45.z >= ( ( 1.0 - nodeVar67.y ) - 0.00146484375 ) ) ) && ( ( nodeVar45.z <= ( nodeVar67.w + 0.00146484375 ) ) || ( nodeVar45.z >= ( nodeVar67.z - 0.00146484375 ) ) ) ) ) {

							nodeVar46 = true;
							

						}

						

					}

					

				}


				if ( nodeVar46 ) {

					nodeVar12 = true;
					break;
					

				}

				nodeVar14 = nodeVar13;
				nodeVar13 = ( nodeVar13 + nodeVar15 );
				

			} else {

				nodeVar68 = ( ( ( ( nodeVar17 + step( 0.0, nodeVar6 ) ) * vec3( 0.0078125 ) ) - nodeVar5 ) * nodeVar7 );
				nodeVar69 = max( min( min( nodeVar68.x, nodeVar68.y ), nodeVar68.z ), nodeVar13 );
				nodeVar14 = nodeVar69;
				nodeVar13 = ( nodeVar69 + ( nodeVar15 * 0.05 ) );
				

			}


		}

		

	}


	if ( ( ! nodeVar12 ) ) {

		discard;
		

	}


	if ( ( nodeVar13 > nodeVar10 ) ) {

		nodeVar70 = nodeVar14;
		nodeVar71 = nodeVar13;

		for ( int i = 0; i < 6; i ++ ) {

			nodeVar72 = ( ( nodeVar70 + nodeVar71 ) * 0.5 );
			nodeVar73 = ( nodeVar5 + ( nodeVar6 * vec3( nodeVar72 ) ) );
			nodeVar74 = false;
			nodeVar75 = clamp( vec2( nodeVar73.z, nodeVar73.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
			nodeVar76 = ( vec2( ( nodeVar75.x + 0.0 ), nodeVar75.y ) / vec2( 3.0, 1.0 ) );
			nodeVar77 = nodeVar76;
			nodeVar79 = bool( nodeUniform13 );

			if ( nodeVar79 ) {

				nodeVar80 = nodeVar77;
				nodeVar78 = vec2( nodeVar80.x, 1.0 - nodeVar80.y );

			} else {

				nodeVar78 = nodeVar77;

			}

			nodeVar81 = textureLod( nodeUniform9, nodeVar78, 0.0 );

			if ( ( ( ( nodeVar73.x <= ( nodeVar81.x + 0.00146484375 ) ) && ( nodeVar73.x >= ( ( 1.0 - nodeVar81.y ) - 0.00146484375 ) ) ) && ( ( nodeVar73.x <= ( nodeVar81.w + 0.00146484375 ) ) || ( nodeVar73.x >= ( nodeVar81.z - 0.00146484375 ) ) ) ) ) {

				nodeVar82 = clamp( vec2( nodeVar73.x, nodeVar73.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
				nodeVar83 = ( vec2( ( nodeVar82.x + 1.0 ), nodeVar82.y ) / vec2( 3.0, 1.0 ) );
				nodeVar84 = nodeVar83;
				nodeVar86 = bool( nodeUniform14 );

				if ( nodeVar86 ) {

					nodeVar87 = nodeVar84;
					nodeVar85 = vec2( nodeVar87.x, 1.0 - nodeVar87.y );

				} else {

					nodeVar85 = nodeVar84;

				}

				nodeVar88 = textureLod( nodeUniform9, nodeVar85, 0.0 );

				if ( ( ( ( nodeVar73.y <= ( nodeVar88.x + 0.00146484375 ) ) && ( nodeVar73.y >= ( ( 1.0 - nodeVar88.y ) - 0.00146484375 ) ) ) && ( ( nodeVar73.y <= ( nodeVar88.w + 0.00146484375 ) ) || ( nodeVar73.y >= ( nodeVar88.z - 0.00146484375 ) ) ) ) ) {

					nodeVar89 = clamp( vec2( nodeVar73.x, nodeVar73.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
					nodeVar90 = ( vec2( ( nodeVar89.x + 2.0 ), nodeVar89.y ) / vec2( 3.0, 1.0 ) );
					nodeVar91 = nodeVar90;
					nodeVar93 = bool( nodeUniform15 );

					if ( nodeVar93 ) {

						nodeVar94 = nodeVar91;
						nodeVar92 = vec2( nodeVar94.x, 1.0 - nodeVar94.y );

					} else {

						nodeVar92 = nodeVar91;

					}

					nodeVar95 = textureLod( nodeUniform9, nodeVar92, 0.0 );

					if ( ( ( ( nodeVar73.z <= ( nodeVar95.x + 0.00146484375 ) ) && ( nodeVar73.z >= ( ( 1.0 - nodeVar95.y ) - 0.00146484375 ) ) ) && ( ( nodeVar73.z <= ( nodeVar95.w + 0.00146484375 ) ) || ( nodeVar73.z >= ( nodeVar95.z - 0.00146484375 ) ) ) ) ) {

						nodeVar74 = true;
						

					}

					

				}

				

			}


			if ( nodeVar74 ) {

				nodeVar71 = nodeVar72;
				

			} else {

				nodeVar70 = nodeVar72;
				

			}


		}

		nodeVar13 = nodeVar71;
		

	}

	nodeVar96 = ( nodeVar5 + ( nodeVar6 * vec3( nodeVar13 ) ) );
	nodeVar97 = clamp( vec2( nodeVar96.z, nodeVar96.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar98 = ( vec2( ( nodeVar97.x + 0.0 ), nodeVar97.y ) / vec2( 3.0, 1.0 ) );
	nodeVar99 = nodeVar98;
	nodeVar101 = bool( nodeUniform16 );

	if ( nodeVar101 ) {

		nodeVar102 = nodeVar99;
		nodeVar100 = vec2( nodeVar102.x, 1.0 - nodeVar102.y );

	} else {

		nodeVar100 = nodeVar99;

	}

	nodeVar103 = textureLod( nodeUniform9, nodeVar100, 0.0 );
	nodeVar104 = abs( ( nodeVar103.x - nodeVar96.x ) );
	nodeVar105 = abs( ( nodeVar96.x - ( 1.0 - nodeVar103.y ) ) );
	nodeVar106 = clamp( vec2( nodeVar96.x, nodeVar96.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar107 = ( vec2( ( nodeVar106.x + 1.0 ), nodeVar106.y ) / vec2( 3.0, 1.0 ) );
	nodeVar108 = nodeVar107;
	nodeVar110 = bool( nodeUniform17 );

	if ( nodeVar110 ) {

		nodeVar111 = nodeVar108;
		nodeVar109 = vec2( nodeVar111.x, 1.0 - nodeVar111.y );

	} else {

		nodeVar109 = nodeVar108;

	}

	nodeVar112 = textureLod( nodeUniform9, nodeVar109, 0.0 );
	nodeVar113 = abs( ( nodeVar112.x - nodeVar96.y ) );
	nodeVar114 = abs( ( nodeVar96.y - ( 1.0 - nodeVar112.y ) ) );
	nodeVar115 = clamp( vec2( nodeVar96.x, nodeVar96.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar116 = ( vec2( ( nodeVar115.x + 2.0 ), nodeVar115.y ) / vec2( 3.0, 1.0 ) );
	nodeVar117 = nodeVar116;
	nodeVar119 = bool( nodeUniform18 );

	if ( nodeVar119 ) {

		nodeVar120 = nodeVar117;
		nodeVar118 = vec2( nodeVar120.x, 1.0 - nodeVar120.y );

	} else {

		nodeVar118 = nodeVar117;

	}

	nodeVar121 = textureLod( nodeUniform9, nodeVar118, 0.0 );
	nodeVar122 = abs( ( nodeVar121.x - nodeVar96.z ) );
	nodeVar123 = abs( ( nodeVar96.z - ( 1.0 - nodeVar121.y ) ) );
	nodeVar124 = min( min( min( min( min( nodeVar104, nodeVar105 ), nodeVar113 ), nodeVar114 ), nodeVar122 ), nodeVar123 );
	nodeVar125 = ( - normalize( nodeVar4 ) );
	nodeVar126 = vec3( 0.0, 0.0, 0.0 );
	nodeVar127 = vec3( 0.0, 0.0, 0.0 );
	nodeVar128 = 0.00001;
	nodeVar129 = vec3( 0.0, 0.0, 0.0 );
	nodeVar130 = 0.00001;
	nodeVar131 = clamp( vec2( ( 1.0 - nodeVar96.z ), nodeVar96.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar132 = ( vec2( ( nodeVar131.x + 0.0 ), ( nodeVar131.y + 0.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar133 = nodeVar132;
	nodeVar135 = bool( nodeUniform20 );

	if ( nodeVar135 ) {

		nodeVar136 = nodeVar133;
		nodeVar134 = vec2( nodeVar136.x, 1.0 - nodeVar136.y );

	} else {

		nodeVar134 = nodeVar133;

	}

	nodeVar137 = textureLod( nodeUniform19, nodeVar134, 0.0 );
	nodeVar138 = nodeVar132;
	nodeVar140 = bool( nodeUniform22 );

	if ( nodeVar140 ) {

		nodeVar141 = nodeVar138;
		nodeVar139 = vec2( nodeVar141.x, 1.0 - nodeVar141.y );

	} else {

		nodeVar139 = nodeVar138;

	}

	nodeVar142 = textureLod( nodeUniform21, nodeVar139, 0.0 );
	nodeVar143 = ( ( ( nodeVar137.xyz / vec3( max( nodeVar142.w, 0.001 ) ) ) * vec3( 2.0 ) ) - vec3( 1.0 ) );
	nodeVar144 = max( dot( nodeVar143, vec3( 1.0, 0.0, 0.0 ) ), 0.0 );
	nodeVar145 = ( ( exp( ( ( nodeVar104 - nodeVar124 ) * -512.0 ) ) * nodeVar142.w ) * ( ( nodeVar144 * nodeVar144 ) + 0.001 ) );
	nodeVar146 = ( nodeVar145 * smoothstep( -0.2, 0.1, dot( nodeVar143, nodeVar125 ) ) );
	nodeVar147 = ( nodeVar142.xyz / vec3( max( nodeVar142.w, 0.001 ) ) );
	nodeVar126 = ( nodeVar126 + ( nodeVar147 * vec3( nodeVar146 ) ) );
	nodeVar127 = ( nodeVar127 + ( nodeVar143 * vec3( nodeVar146 ) ) );
	nodeVar128 = ( nodeVar128 + nodeVar146 );
	nodeVar129 = ( nodeVar129 + ( nodeVar147 * vec3( nodeVar145 ) ) );
	nodeVar130 = ( nodeVar130 + nodeVar145 );
	nodeVar148 = clamp( vec2( nodeVar96.z, nodeVar96.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar149 = ( vec2( ( nodeVar148.x + 1.0 ), ( nodeVar148.y + 0.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar150 = nodeVar149;
	nodeVar152 = bool( nodeUniform23 );

	if ( nodeVar152 ) {

		nodeVar153 = nodeVar150;
		nodeVar151 = vec2( nodeVar153.x, 1.0 - nodeVar153.y );

	} else {

		nodeVar151 = nodeVar150;

	}

	nodeVar154 = textureLod( nodeUniform19, nodeVar151, 0.0 );
	nodeVar155 = nodeVar149;
	nodeVar157 = bool( nodeUniform24 );

	if ( nodeVar157 ) {

		nodeVar158 = nodeVar155;
		nodeVar156 = vec2( nodeVar158.x, 1.0 - nodeVar158.y );

	} else {

		nodeVar156 = nodeVar155;

	}

	nodeVar159 = textureLod( nodeUniform21, nodeVar156, 0.0 );
	nodeVar160 = ( ( ( nodeVar154.xyz / vec3( max( nodeVar159.w, 0.001 ) ) ) * vec3( 2.0 ) ) - vec3( 1.0 ) );
	nodeVar161 = max( dot( nodeVar160, vec3( -1.0, 0.0, 0.0 ) ), 0.0 );
	nodeVar162 = ( ( exp( ( ( nodeVar105 - nodeVar124 ) * -512.0 ) ) * nodeVar159.w ) * ( ( nodeVar161 * nodeVar161 ) + 0.001 ) );
	nodeVar163 = ( nodeVar162 * smoothstep( -0.2, 0.1, dot( nodeVar160, nodeVar125 ) ) );
	nodeVar164 = ( nodeVar159.xyz / vec3( max( nodeVar159.w, 0.001 ) ) );
	nodeVar126 = ( nodeVar126 + ( nodeVar164 * vec3( nodeVar163 ) ) );
	nodeVar127 = ( nodeVar127 + ( nodeVar160 * vec3( nodeVar163 ) ) );
	nodeVar128 = ( nodeVar128 + nodeVar163 );
	nodeVar129 = ( nodeVar129 + ( nodeVar164 * vec3( nodeVar162 ) ) );
	nodeVar130 = ( nodeVar130 + nodeVar162 );
	nodeVar165 = clamp( vec2( nodeVar96.x, ( 1.0 - nodeVar96.z ) ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar166 = ( vec2( ( nodeVar165.x + 2.0 ), ( nodeVar165.y + 0.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar167 = nodeVar166;
	nodeVar169 = bool( nodeUniform25 );

	if ( nodeVar169 ) {

		nodeVar170 = nodeVar167;
		nodeVar168 = vec2( nodeVar170.x, 1.0 - nodeVar170.y );

	} else {

		nodeVar168 = nodeVar167;

	}

	nodeVar171 = textureLod( nodeUniform19, nodeVar168, 0.0 );
	nodeVar172 = nodeVar166;
	nodeVar174 = bool( nodeUniform26 );

	if ( nodeVar174 ) {

		nodeVar175 = nodeVar172;
		nodeVar173 = vec2( nodeVar175.x, 1.0 - nodeVar175.y );

	} else {

		nodeVar173 = nodeVar172;

	}

	nodeVar176 = textureLod( nodeUniform21, nodeVar173, 0.0 );
	nodeVar177 = ( ( ( nodeVar171.xyz / vec3( max( nodeVar176.w, 0.001 ) ) ) * vec3( 2.0 ) ) - vec3( 1.0 ) );
	nodeVar178 = max( dot( nodeVar177, vec3( 0.0, 1.0, 0.0 ) ), 0.0 );
	nodeVar179 = ( ( exp( ( ( nodeVar113 - nodeVar124 ) * -512.0 ) ) * nodeVar176.w ) * ( ( nodeVar178 * nodeVar178 ) + 0.001 ) );
	nodeVar180 = ( nodeVar179 * smoothstep( -0.2, 0.1, dot( nodeVar177, nodeVar125 ) ) );
	nodeVar181 = ( nodeVar176.xyz / vec3( max( nodeVar176.w, 0.001 ) ) );
	nodeVar126 = ( nodeVar126 + ( nodeVar181 * vec3( nodeVar180 ) ) );
	nodeVar127 = ( nodeVar127 + ( nodeVar177 * vec3( nodeVar180 ) ) );
	nodeVar128 = ( nodeVar128 + nodeVar180 );
	nodeVar129 = ( nodeVar129 + ( nodeVar181 * vec3( nodeVar179 ) ) );
	nodeVar130 = ( nodeVar130 + nodeVar179 );
	nodeVar182 = clamp( vec2( nodeVar96.x, nodeVar96.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar183 = ( vec2( ( nodeVar182.x + 0.0 ), ( nodeVar182.y + 1.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar184 = nodeVar183;
	nodeVar186 = bool( nodeUniform27 );

	if ( nodeVar186 ) {

		nodeVar187 = nodeVar184;
		nodeVar185 = vec2( nodeVar187.x, 1.0 - nodeVar187.y );

	} else {

		nodeVar185 = nodeVar184;

	}

	nodeVar188 = textureLod( nodeUniform19, nodeVar185, 0.0 );
	nodeVar189 = nodeVar183;
	nodeVar191 = bool( nodeUniform28 );

	if ( nodeVar191 ) {

		nodeVar192 = nodeVar189;
		nodeVar190 = vec2( nodeVar192.x, 1.0 - nodeVar192.y );

	} else {

		nodeVar190 = nodeVar189;

	}

	nodeVar193 = textureLod( nodeUniform21, nodeVar190, 0.0 );
	nodeVar194 = ( ( ( nodeVar188.xyz / vec3( max( nodeVar193.w, 0.001 ) ) ) * vec3( 2.0 ) ) - vec3( 1.0 ) );
	nodeVar195 = max( dot( nodeVar194, vec3( 0.0, -1.0, 0.0 ) ), 0.0 );
	nodeVar196 = ( ( exp( ( ( nodeVar114 - nodeVar124 ) * -512.0 ) ) * nodeVar193.w ) * ( ( nodeVar195 * nodeVar195 ) + 0.001 ) );
	nodeVar197 = ( nodeVar196 * smoothstep( -0.2, 0.1, dot( nodeVar194, nodeVar125 ) ) );
	nodeVar198 = ( nodeVar193.xyz / vec3( max( nodeVar193.w, 0.001 ) ) );
	nodeVar126 = ( nodeVar126 + ( nodeVar198 * vec3( nodeVar197 ) ) );
	nodeVar127 = ( nodeVar127 + ( nodeVar194 * vec3( nodeVar197 ) ) );
	nodeVar128 = ( nodeVar128 + nodeVar197 );
	nodeVar129 = ( nodeVar129 + ( nodeVar198 * vec3( nodeVar196 ) ) );
	nodeVar130 = ( nodeVar130 + nodeVar196 );
	nodeVar199 = clamp( vec2( nodeVar96.x, nodeVar96.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar200 = ( vec2( ( nodeVar199.x + 1.0 ), ( nodeVar199.y + 1.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar201 = nodeVar200;
	nodeVar203 = bool( nodeUniform29 );

	if ( nodeVar203 ) {

		nodeVar204 = nodeVar201;
		nodeVar202 = vec2( nodeVar204.x, 1.0 - nodeVar204.y );

	} else {

		nodeVar202 = nodeVar201;

	}

	nodeVar205 = textureLod( nodeUniform19, nodeVar202, 0.0 );
	nodeVar206 = nodeVar200;
	nodeVar208 = bool( nodeUniform30 );

	if ( nodeVar208 ) {

		nodeVar209 = nodeVar206;
		nodeVar207 = vec2( nodeVar209.x, 1.0 - nodeVar209.y );

	} else {

		nodeVar207 = nodeVar206;

	}

	nodeVar210 = textureLod( nodeUniform21, nodeVar207, 0.0 );
	nodeVar211 = ( ( ( nodeVar205.xyz / vec3( max( nodeVar210.w, 0.001 ) ) ) * vec3( 2.0 ) ) - vec3( 1.0 ) );
	nodeVar212 = max( dot( nodeVar211, vec3( 0.0, 0.0, 1.0 ) ), 0.0 );
	nodeVar213 = ( ( exp( ( ( nodeVar122 - nodeVar124 ) * -512.0 ) ) * nodeVar210.w ) * ( ( nodeVar212 * nodeVar212 ) + 0.001 ) );
	nodeVar214 = ( nodeVar213 * smoothstep( -0.2, 0.1, dot( nodeVar211, nodeVar125 ) ) );
	nodeVar215 = ( nodeVar210.xyz / vec3( max( nodeVar210.w, 0.001 ) ) );
	nodeVar126 = ( nodeVar126 + ( nodeVar215 * vec3( nodeVar214 ) ) );
	nodeVar127 = ( nodeVar127 + ( nodeVar211 * vec3( nodeVar214 ) ) );
	nodeVar128 = ( nodeVar128 + nodeVar214 );
	nodeVar129 = ( nodeVar129 + ( nodeVar215 * vec3( nodeVar213 ) ) );
	nodeVar130 = ( nodeVar130 + nodeVar213 );
	nodeVar216 = clamp( vec2( ( 1.0 - nodeVar96.x ), nodeVar96.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar217 = ( vec2( ( nodeVar216.x + 2.0 ), ( nodeVar216.y + 1.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar218 = nodeVar217;
	nodeVar220 = bool( nodeUniform31 );

	if ( nodeVar220 ) {

		nodeVar221 = nodeVar218;
		nodeVar219 = vec2( nodeVar221.x, 1.0 - nodeVar221.y );

	} else {

		nodeVar219 = nodeVar218;

	}

	nodeVar222 = textureLod( nodeUniform19, nodeVar219, 0.0 );
	nodeVar223 = nodeVar217;
	nodeVar225 = bool( nodeUniform32 );

	if ( nodeVar225 ) {

		nodeVar226 = nodeVar223;
		nodeVar224 = vec2( nodeVar226.x, 1.0 - nodeVar226.y );

	} else {

		nodeVar224 = nodeVar223;

	}

	nodeVar227 = textureLod( nodeUniform21, nodeVar224, 0.0 );
	nodeVar228 = ( ( ( nodeVar222.xyz / vec3( max( nodeVar227.w, 0.001 ) ) ) * vec3( 2.0 ) ) - vec3( 1.0 ) );
	nodeVar229 = max( dot( nodeVar228, vec3( 0.0, 0.0, -1.0 ) ), 0.0 );
	nodeVar230 = ( ( exp( ( ( nodeVar123 - nodeVar124 ) * -512.0 ) ) * nodeVar227.w ) * ( ( nodeVar229 * nodeVar229 ) + 0.001 ) );
	nodeVar231 = ( nodeVar230 * smoothstep( -0.2, 0.1, dot( nodeVar228, nodeVar125 ) ) );
	nodeVar232 = ( nodeVar227.xyz / vec3( max( nodeVar227.w, 0.001 ) ) );
	nodeVar126 = ( nodeVar126 + ( nodeVar232 * vec3( nodeVar231 ) ) );
	nodeVar127 = ( nodeVar127 + ( nodeVar228 * vec3( nodeVar231 ) ) );
	nodeVar128 = ( nodeVar128 + nodeVar231 );
	nodeVar129 = ( nodeVar129 + ( nodeVar232 * vec3( nodeVar230 ) ) );
	nodeVar130 = ( nodeVar130 + nodeVar230 );
	nodeVar233 = ( nodeVar128 > 0.001 );

	if ( nodeVar233 ) {

		nodeVar234 = ( nodeVar126 / vec3( nodeVar128 ) );

	} else {

		nodeVar234 = ( nodeVar129 / vec3( nodeVar130 ) );

	}

	nodeVar126 = nodeVar234;

	if ( ( nodeVar233 && ( length( nodeVar127 ) > 0.0001 ) ) ) {

		nodeVar235 = normalize( nodeVar127 );

	} else {

		nodeVar235 = nodeVar125;

	}

	nodeVar236 = nodeVar235;

	if ( ( nodeVar124 > 0.0029296875 ) ) {

		nodeVar237 = ( nodeVar96 + vec3( 0.001953125, 0.0, 0.0 ) );
		nodeVar238 = clamp( vec2( nodeVar237.z, nodeVar237.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar239 = ( vec2( ( nodeVar238.x + 0.0 ), nodeVar238.y ) / vec2( 3.0, 1.0 ) );
		nodeVar240 = nodeVar239;
		nodeVar242 = bool( nodeUniform33 );

		if ( nodeVar242 ) {

			nodeVar243 = nodeVar240;
			nodeVar241 = vec2( nodeVar243.x, 1.0 - nodeVar243.y );

		} else {

			nodeVar241 = nodeVar240;

		}

		nodeVar244 = textureLod( nodeUniform9, nodeVar241, 0.0 );
		nodeVar245 = clamp( vec2( nodeVar237.x, nodeVar237.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar246 = ( vec2( ( nodeVar245.x + 1.0 ), nodeVar245.y ) / vec2( 3.0, 1.0 ) );
		nodeVar247 = nodeVar246;
		nodeVar249 = bool( nodeUniform34 );

		if ( nodeVar249 ) {

			nodeVar250 = nodeVar247;
			nodeVar248 = vec2( nodeVar250.x, 1.0 - nodeVar250.y );

		} else {

			nodeVar248 = nodeVar247;

		}

		nodeVar251 = textureLod( nodeUniform9, nodeVar248, 0.0 );
		nodeVar252 = clamp( vec2( nodeVar237.x, nodeVar237.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar253 = ( vec2( ( nodeVar252.x + 2.0 ), nodeVar252.y ) / vec2( 3.0, 1.0 ) );
		nodeVar254 = nodeVar253;
		nodeVar256 = bool( nodeUniform35 );

		if ( nodeVar256 ) {

			nodeVar257 = nodeVar254;
			nodeVar255 = vec2( nodeVar257.x, 1.0 - nodeVar257.y );

		} else {

			nodeVar255 = nodeVar254;

		}

		nodeVar258 = textureLod( nodeUniform9, nodeVar255, 0.0 );
		nodeVar259 = ( nodeVar96 - vec3( 0.001953125, 0.0, 0.0 ) );
		nodeVar260 = clamp( vec2( nodeVar259.z, nodeVar259.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar261 = ( vec2( ( nodeVar260.x + 0.0 ), nodeVar260.y ) / vec2( 3.0, 1.0 ) );
		nodeVar262 = nodeVar261;
		nodeVar264 = bool( nodeUniform36 );

		if ( nodeVar264 ) {

			nodeVar265 = nodeVar262;
			nodeVar263 = vec2( nodeVar265.x, 1.0 - nodeVar265.y );

		} else {

			nodeVar263 = nodeVar262;

		}

		nodeVar266 = textureLod( nodeUniform9, nodeVar263, 0.0 );
		nodeVar267 = clamp( vec2( nodeVar259.x, nodeVar259.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar268 = ( vec2( ( nodeVar267.x + 1.0 ), nodeVar267.y ) / vec2( 3.0, 1.0 ) );
		nodeVar269 = nodeVar268;
		nodeVar271 = bool( nodeUniform37 );

		if ( nodeVar271 ) {

			nodeVar272 = nodeVar269;
			nodeVar270 = vec2( nodeVar272.x, 1.0 - nodeVar272.y );

		} else {

			nodeVar270 = nodeVar269;

		}

		nodeVar273 = textureLod( nodeUniform9, nodeVar270, 0.0 );
		nodeVar274 = clamp( vec2( nodeVar259.x, nodeVar259.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar275 = ( vec2( ( nodeVar274.x + 2.0 ), nodeVar274.y ) / vec2( 3.0, 1.0 ) );
		nodeVar276 = nodeVar275;
		nodeVar278 = bool( nodeUniform38 );

		if ( nodeVar278 ) {

			nodeVar279 = nodeVar276;
			nodeVar277 = vec2( nodeVar279.x, 1.0 - nodeVar279.y );

		} else {

			nodeVar277 = nodeVar276;

		}

		nodeVar280 = textureLod( nodeUniform9, nodeVar277, 0.0 );
		nodeVar281 = ( nodeVar96 + vec3( 0.0, 0.001953125, 0.0 ) );
		nodeVar282 = clamp( vec2( nodeVar281.z, nodeVar281.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar283 = ( vec2( ( nodeVar282.x + 0.0 ), nodeVar282.y ) / vec2( 3.0, 1.0 ) );
		nodeVar284 = nodeVar283;
		nodeVar286 = bool( nodeUniform39 );

		if ( nodeVar286 ) {

			nodeVar287 = nodeVar284;
			nodeVar285 = vec2( nodeVar287.x, 1.0 - nodeVar287.y );

		} else {

			nodeVar285 = nodeVar284;

		}

		nodeVar288 = textureLod( nodeUniform9, nodeVar285, 0.0 );
		nodeVar289 = clamp( vec2( nodeVar281.x, nodeVar281.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar290 = ( vec2( ( nodeVar289.x + 1.0 ), nodeVar289.y ) / vec2( 3.0, 1.0 ) );
		nodeVar291 = nodeVar290;
		nodeVar293 = bool( nodeUniform40 );

		if ( nodeVar293 ) {

			nodeVar294 = nodeVar291;
			nodeVar292 = vec2( nodeVar294.x, 1.0 - nodeVar294.y );

		} else {

			nodeVar292 = nodeVar291;

		}

		nodeVar295 = textureLod( nodeUniform9, nodeVar292, 0.0 );
		nodeVar296 = clamp( vec2( nodeVar281.x, nodeVar281.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar297 = ( vec2( ( nodeVar296.x + 2.0 ), nodeVar296.y ) / vec2( 3.0, 1.0 ) );
		nodeVar298 = nodeVar297;
		nodeVar300 = bool( nodeUniform41 );

		if ( nodeVar300 ) {

			nodeVar301 = nodeVar298;
			nodeVar299 = vec2( nodeVar301.x, 1.0 - nodeVar301.y );

		} else {

			nodeVar299 = nodeVar298;

		}

		nodeVar302 = textureLod( nodeUniform9, nodeVar299, 0.0 );
		nodeVar303 = ( nodeVar96 - vec3( 0.0, 0.001953125, 0.0 ) );
		nodeVar304 = clamp( vec2( nodeVar303.z, nodeVar303.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar305 = ( vec2( ( nodeVar304.x + 0.0 ), nodeVar304.y ) / vec2( 3.0, 1.0 ) );
		nodeVar306 = nodeVar305;
		nodeVar308 = bool( nodeUniform42 );

		if ( nodeVar308 ) {

			nodeVar309 = nodeVar306;
			nodeVar307 = vec2( nodeVar309.x, 1.0 - nodeVar309.y );

		} else {

			nodeVar307 = nodeVar306;

		}

		nodeVar310 = textureLod( nodeUniform9, nodeVar307, 0.0 );
		nodeVar311 = clamp( vec2( nodeVar303.x, nodeVar303.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar312 = ( vec2( ( nodeVar311.x + 1.0 ), nodeVar311.y ) / vec2( 3.0, 1.0 ) );
		nodeVar313 = nodeVar312;
		nodeVar315 = bool( nodeUniform43 );

		if ( nodeVar315 ) {

			nodeVar316 = nodeVar313;
			nodeVar314 = vec2( nodeVar316.x, 1.0 - nodeVar316.y );

		} else {

			nodeVar314 = nodeVar313;

		}

		nodeVar317 = textureLod( nodeUniform9, nodeVar314, 0.0 );
		nodeVar318 = clamp( vec2( nodeVar303.x, nodeVar303.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar319 = ( vec2( ( nodeVar318.x + 2.0 ), nodeVar318.y ) / vec2( 3.0, 1.0 ) );
		nodeVar320 = nodeVar319;
		nodeVar322 = bool( nodeUniform44 );

		if ( nodeVar322 ) {

			nodeVar323 = nodeVar320;
			nodeVar321 = vec2( nodeVar323.x, 1.0 - nodeVar323.y );

		} else {

			nodeVar321 = nodeVar320;

		}

		nodeVar324 = textureLod( nodeUniform9, nodeVar321, 0.0 );
		nodeVar325 = ( nodeVar96 + vec3( 0.0, 0.0, 0.001953125 ) );
		nodeVar326 = clamp( vec2( nodeVar325.z, nodeVar325.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar327 = ( vec2( ( nodeVar326.x + 0.0 ), nodeVar326.y ) / vec2( 3.0, 1.0 ) );
		nodeVar328 = nodeVar327;
		nodeVar330 = bool( nodeUniform45 );

		if ( nodeVar330 ) {

			nodeVar331 = nodeVar328;
			nodeVar329 = vec2( nodeVar331.x, 1.0 - nodeVar331.y );

		} else {

			nodeVar329 = nodeVar328;

		}

		nodeVar332 = textureLod( nodeUniform9, nodeVar329, 0.0 );
		nodeVar333 = clamp( vec2( nodeVar325.x, nodeVar325.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar334 = ( vec2( ( nodeVar333.x + 1.0 ), nodeVar333.y ) / vec2( 3.0, 1.0 ) );
		nodeVar335 = nodeVar334;
		nodeVar337 = bool( nodeUniform46 );

		if ( nodeVar337 ) {

			nodeVar338 = nodeVar335;
			nodeVar336 = vec2( nodeVar338.x, 1.0 - nodeVar338.y );

		} else {

			nodeVar336 = nodeVar335;

		}

		nodeVar339 = textureLod( nodeUniform9, nodeVar336, 0.0 );
		nodeVar340 = clamp( vec2( nodeVar325.x, nodeVar325.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar341 = ( vec2( ( nodeVar340.x + 2.0 ), nodeVar340.y ) / vec2( 3.0, 1.0 ) );
		nodeVar342 = nodeVar341;
		nodeVar344 = bool( nodeUniform47 );

		if ( nodeVar344 ) {

			nodeVar345 = nodeVar342;
			nodeVar343 = vec2( nodeVar345.x, 1.0 - nodeVar345.y );

		} else {

			nodeVar343 = nodeVar342;

		}

		nodeVar346 = textureLod( nodeUniform9, nodeVar343, 0.0 );
		nodeVar347 = ( nodeVar96 - vec3( 0.0, 0.0, 0.001953125 ) );
		nodeVar348 = clamp( vec2( nodeVar347.z, nodeVar347.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar349 = ( vec2( ( nodeVar348.x + 0.0 ), nodeVar348.y ) / vec2( 3.0, 1.0 ) );
		nodeVar350 = nodeVar349;
		nodeVar352 = bool( nodeUniform48 );

		if ( nodeVar352 ) {

			nodeVar353 = nodeVar350;
			nodeVar351 = vec2( nodeVar353.x, 1.0 - nodeVar353.y );

		} else {

			nodeVar351 = nodeVar350;

		}

		nodeVar354 = textureLod( nodeUniform9, nodeVar351, 0.0 );
		nodeVar355 = clamp( vec2( nodeVar347.x, nodeVar347.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar356 = ( vec2( ( nodeVar355.x + 1.0 ), nodeVar355.y ) / vec2( 3.0, 1.0 ) );
		nodeVar357 = nodeVar356;
		nodeVar359 = bool( nodeUniform49 );

		if ( nodeVar359 ) {

			nodeVar360 = nodeVar357;
			nodeVar358 = vec2( nodeVar360.x, 1.0 - nodeVar360.y );

		} else {

			nodeVar358 = nodeVar357;

		}

		nodeVar361 = textureLod( nodeUniform9, nodeVar358, 0.0 );
		nodeVar362 = clamp( vec2( nodeVar347.x, nodeVar347.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
		nodeVar363 = ( vec2( ( nodeVar362.x + 2.0 ), nodeVar362.y ) / vec2( 3.0, 1.0 ) );
		nodeVar364 = nodeVar363;
		nodeVar366 = bool( nodeUniform50 );

		if ( nodeVar366 ) {

			nodeVar367 = nodeVar364;
			nodeVar365 = vec2( nodeVar367.x, 1.0 - nodeVar367.y );

		} else {

			nodeVar365 = nodeVar364;

		}

		nodeVar368 = textureLod( nodeUniform9, nodeVar365, 0.0 );
		nodeVar236 = mix( normalize( ( vec3( ( max( max( max( max( ( nodeVar237.x - nodeVar244.x ), ( ( 1.0 - nodeVar244.y ) - nodeVar237.x ) ), min( ( nodeVar237.x - nodeVar244.w ), ( nodeVar244.z - nodeVar237.x ) ) ), max( max( ( nodeVar237.y - nodeVar251.x ), ( ( 1.0 - nodeVar251.y ) - nodeVar237.y ) ), min( ( nodeVar237.y - nodeVar251.w ), ( nodeVar251.z - nodeVar237.y ) ) ) ), max( max( ( nodeVar237.z - nodeVar258.x ), ( ( 1.0 - nodeVar258.y ) - nodeVar237.z ) ), min( ( nodeVar237.z - nodeVar258.w ), ( nodeVar258.z - nodeVar237.z ) ) ) ) - max( max( max( max( ( nodeVar259.x - nodeVar266.x ), ( ( 1.0 - nodeVar266.y ) - nodeVar259.x ) ), min( ( nodeVar259.x - nodeVar266.w ), ( nodeVar266.z - nodeVar259.x ) ) ), max( max( ( nodeVar259.y - nodeVar273.x ), ( ( 1.0 - nodeVar273.y ) - nodeVar259.y ) ), min( ( nodeVar259.y - nodeVar273.w ), ( nodeVar273.z - nodeVar259.y ) ) ) ), max( max( ( nodeVar259.z - nodeVar280.x ), ( ( 1.0 - nodeVar280.y ) - nodeVar259.z ) ), min( ( nodeVar259.z - nodeVar280.w ), ( nodeVar280.z - nodeVar259.z ) ) ) ) ), ( max( max( max( max( ( nodeVar281.x - nodeVar288.x ), ( ( 1.0 - nodeVar288.y ) - nodeVar281.x ) ), min( ( nodeVar281.x - nodeVar288.w ), ( nodeVar288.z - nodeVar281.x ) ) ), max( max( ( nodeVar281.y - nodeVar295.x ), ( ( 1.0 - nodeVar295.y ) - nodeVar281.y ) ), min( ( nodeVar281.y - nodeVar295.w ), ( nodeVar295.z - nodeVar281.y ) ) ) ), max( max( ( nodeVar281.z - nodeVar302.x ), ( ( 1.0 - nodeVar302.y ) - nodeVar281.z ) ), min( ( nodeVar281.z - nodeVar302.w ), ( nodeVar302.z - nodeVar281.z ) ) ) ) - max( max( max( max( ( nodeVar303.x - nodeVar310.x ), ( ( 1.0 - nodeVar310.y ) - nodeVar303.x ) ), min( ( nodeVar303.x - nodeVar310.w ), ( nodeVar310.z - nodeVar303.x ) ) ), max( max( ( nodeVar303.y - nodeVar317.x ), ( ( 1.0 - nodeVar317.y ) - nodeVar303.y ) ), min( ( nodeVar303.y - nodeVar317.w ), ( nodeVar317.z - nodeVar303.y ) ) ) ), max( max( ( nodeVar303.z - nodeVar324.x ), ( ( 1.0 - nodeVar324.y ) - nodeVar303.z ) ), min( ( nodeVar303.z - nodeVar324.w ), ( nodeVar324.z - nodeVar303.z ) ) ) ) ), ( max( max( max( max( ( nodeVar325.x - nodeVar332.x ), ( ( 1.0 - nodeVar332.y ) - nodeVar325.x ) ), min( ( nodeVar325.x - nodeVar332.w ), ( nodeVar332.z - nodeVar325.x ) ) ), max( max( ( nodeVar325.y - nodeVar339.x ), ( ( 1.0 - nodeVar339.y ) - nodeVar325.y ) ), min( ( nodeVar325.y - nodeVar339.w ), ( nodeVar339.z - nodeVar325.y ) ) ) ), max( max( ( nodeVar325.z - nodeVar346.x ), ( ( 1.0 - nodeVar346.y ) - nodeVar325.z ) ), min( ( nodeVar325.z - nodeVar346.w ), ( nodeVar346.z - nodeVar325.z ) ) ) ) - max( max( max( max( ( nodeVar347.x - nodeVar354.x ), ( ( 1.0 - nodeVar354.y ) - nodeVar347.x ) ), min( ( nodeVar347.x - nodeVar354.w ), ( nodeVar354.z - nodeVar347.x ) ) ), max( max( ( nodeVar347.y - nodeVar361.x ), ( ( 1.0 - nodeVar361.y ) - nodeVar347.y ) ), min( ( nodeVar347.y - nodeVar361.w ), ( nodeVar361.z - nodeVar347.y ) ) ) ), max( max( ( nodeVar347.z - nodeVar368.x ), ( ( 1.0 - nodeVar368.y ) - nodeVar347.z ) ), min( ( nodeVar347.z - nodeVar368.w ), ( nodeVar368.z - nodeVar347.z ) ) ) ) ) ) / vec3( 0.40023485660552977, 1.04, 0.3785624587535858 ) ) ), nodeVar236, smoothstep( 0.0048828125, 0.0029296875, nodeVar124 ) );
		

	}

	ImpostorNormal = normalize( ( ( ( nodeVarying6 * vec3( nodeVar236.x ) ) + ( nodeVarying7 * vec3( nodeVar236.y ) ) ) + ( nodeVarying8 * vec3( nodeVar236.z ) ) ) );
	nodeVar371 = ( vec3( -0.20011742830276488, -0.52, -0.1892812293767929 ) + ( nodeVar96 * vec3( 0.40023485660552977, 1.04, 0.3785624587535858 ) ) );
	ParallaxNativeHitPosition = nodeVar371;
	ImpostorPositionView = ( ( ( nodeVarying9 + ( nodeVarying10 * vec3( nodeVar371.x ) ) ) + ( nodeVarying11 * vec3( nodeVar371.y ) ) ) + ( nodeVarying12 * vec3( nodeVar371.z ) ) );

	if ( nodeVar1 ) {

		nodeVar372 = ( ( ImpostorPositionView.z + cameraNear ) / ( cameraNear - cameraFar ) );

	} else {

		nodeVar372 = ( ( ( cameraNear + ImpostorPositionView.z ) * cameraFar ) / ( ( cameraFar - cameraNear ) * ImpostorPositionView.z ) );

	}

	ImpostorDepth = nodeVar372;
	nodeVar373 = vec4( ( nodeVar126 * nodeUniform54 ), 1.0 );
	nodeVar374 = ( ( ParallaxNativeHitPosition - vec3( -0.20011742830276488, -0.52, -0.1892812293767929 ) ) / vec3( 0.40023485660552977, 1.04, 0.3785624587535858 ) );

	if ( nodeVar1 ) {

		nodeVar375 = ( nodeVarying3 - ( nodeVarying4 * vec3( ( length( vec3( 0.40023485660552977, 1.04, 0.3785624587535858 ) ) * 4.0 ) ) ) );

	} else {

		nodeVar375 = nodeVarying5;

	}

	nodeVar376 = nodeVar375;
	nodeVar377 = ( nodeVarying3 - nodeVar376 );
	nodeVar378 = ( - normalize( nodeVar377 ) );
	nodeVar379 = clamp( vec2( nodeVar374.z, nodeVar374.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar380 = ( vec2( ( nodeVar379.x + 0.0 ), nodeVar379.y ) / vec2( 3.0, 1.0 ) );
	nodeVar381 = nodeVar380;
	nodeVar383 = bool( nodeUniform55 );

	if ( nodeVar383 ) {

		nodeVar384 = nodeVar381;
		nodeVar382 = vec2( nodeVar384.x, 1.0 - nodeVar384.y );

	} else {

		nodeVar382 = nodeVar381;

	}

	nodeVar385 = textureLod( nodeUniform9, nodeVar382, 0.0 );
	nodeVar386 = ( abs( ( nodeVar385.x - nodeVar374.x ) ) * 1024.0 );
	nodeVar387 = ( abs( ( nodeVar374.x - ( 1.0 - nodeVar385.y ) ) ) * 1024.0 );
	nodeVar388 = clamp( vec2( nodeVar374.x, nodeVar374.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar389 = ( vec2( ( nodeVar388.x + 1.0 ), nodeVar388.y ) / vec2( 3.0, 1.0 ) );
	nodeVar390 = nodeVar389;
	nodeVar392 = bool( nodeUniform56 );

	if ( nodeVar392 ) {

		nodeVar393 = nodeVar390;
		nodeVar391 = vec2( nodeVar393.x, 1.0 - nodeVar393.y );

	} else {

		nodeVar391 = nodeVar390;

	}

	nodeVar394 = textureLod( nodeUniform9, nodeVar391, 0.0 );
	nodeVar395 = ( abs( ( nodeVar394.x - nodeVar374.y ) ) * 1024.0 );
	nodeVar396 = ( abs( ( nodeVar374.y - ( 1.0 - nodeVar394.y ) ) ) * 1024.0 );
	nodeVar397 = clamp( vec2( nodeVar374.x, nodeVar374.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar398 = ( vec2( ( nodeVar397.x + 2.0 ), nodeVar397.y ) / vec2( 3.0, 1.0 ) );
	nodeVar399 = nodeVar398;
	nodeVar401 = bool( nodeUniform57 );

	if ( nodeVar401 ) {

		nodeVar402 = nodeVar399;
		nodeVar400 = vec2( nodeVar402.x, 1.0 - nodeVar402.y );

	} else {

		nodeVar400 = nodeVar399;

	}

	nodeVar403 = textureLod( nodeUniform9, nodeVar400, 0.0 );
	nodeVar404 = ( abs( ( nodeVar403.x - nodeVar374.z ) ) * 1024.0 );
	nodeVar405 = ( abs( ( nodeVar374.z - ( 1.0 - nodeVar403.y ) ) ) * 1024.0 );
	nodeVar406 = clamp( vec2( ( 1.0 - nodeVar374.z ), nodeVar374.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar407 = ( vec2( ( nodeVar406.x + 0.0 ), ( nodeVar406.y + 0.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar408 = nodeVar407;
	nodeVar410 = bool( nodeUniform58 );

	if ( nodeVar410 ) {

		nodeVar411 = nodeVar408;
		nodeVar409 = vec2( nodeVar411.x, 1.0 - nodeVar411.y );

	} else {

		nodeVar409 = nodeVar408;

	}

	nodeVar412 = textureLod( nodeUniform21, nodeVar409, 0.0 );
	nodeVar413 = nodeVar412;
	nodeVar414 = pow( max( dot( nodeVar378, vec3( 1.0, 0.0, 0.0 ) ), 0.0 ), 8.0 );
	nodeVar415 = clamp( vec2( nodeVar374.z, nodeVar374.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar416 = ( vec2( ( nodeVar415.x + 1.0 ), ( nodeVar415.y + 0.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar417 = nodeVar416;
	nodeVar419 = bool( nodeUniform59 );

	if ( nodeVar419 ) {

		nodeVar420 = nodeVar417;
		nodeVar418 = vec2( nodeVar420.x, 1.0 - nodeVar420.y );

	} else {

		nodeVar418 = nodeVar417;

	}

	nodeVar421 = textureLod( nodeUniform21, nodeVar418, 0.0 );
	nodeVar422 = nodeVar421;
	nodeVar423 = pow( max( dot( nodeVar378, vec3( -1.0, 0.0, 0.0 ) ), 0.0 ), 8.0 );
	nodeVar424 = clamp( vec2( nodeVar374.x, ( 1.0 - nodeVar374.z ) ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar425 = ( vec2( ( nodeVar424.x + 2.0 ), ( nodeVar424.y + 0.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar426 = nodeVar425;
	nodeVar428 = bool( nodeUniform60 );

	if ( nodeVar428 ) {

		nodeVar429 = nodeVar426;
		nodeVar427 = vec2( nodeVar429.x, 1.0 - nodeVar429.y );

	} else {

		nodeVar427 = nodeVar426;

	}

	nodeVar430 = textureLod( nodeUniform21, nodeVar427, 0.0 );
	nodeVar431 = nodeVar430;
	nodeVar432 = pow( max( dot( nodeVar378, vec3( 0.0, 1.0, 0.0 ) ), 0.0 ), 8.0 );
	nodeVar433 = clamp( vec2( nodeVar374.x, nodeVar374.z ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar434 = ( vec2( ( nodeVar433.x + 0.0 ), ( nodeVar433.y + 1.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar435 = nodeVar434;
	nodeVar437 = bool( nodeUniform61 );

	if ( nodeVar437 ) {

		nodeVar438 = nodeVar435;
		nodeVar436 = vec2( nodeVar438.x, 1.0 - nodeVar438.y );

	} else {

		nodeVar436 = nodeVar435;

	}

	nodeVar439 = textureLod( nodeUniform21, nodeVar436, 0.0 );
	nodeVar440 = nodeVar439;
	nodeVar441 = pow( max( dot( nodeVar378, vec3( 0.0, -1.0, 0.0 ) ), 0.0 ), 8.0 );
	nodeVar442 = clamp( vec2( nodeVar374.x, nodeVar374.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar443 = ( vec2( ( nodeVar442.x + 1.0 ), ( nodeVar442.y + 1.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar444 = nodeVar443;
	nodeVar446 = bool( nodeUniform62 );

	if ( nodeVar446 ) {

		nodeVar447 = nodeVar444;
		nodeVar445 = vec2( nodeVar447.x, 1.0 - nodeVar447.y );

	} else {

		nodeVar445 = nodeVar444;

	}

	nodeVar448 = textureLod( nodeUniform21, nodeVar445, 0.0 );
	nodeVar449 = nodeVar448;
	nodeVar450 = pow( max( dot( nodeVar378, vec3( 0.0, 0.0, 1.0 ) ), 0.0 ), 8.0 );
	nodeVar451 = clamp( vec2( ( 1.0 - nodeVar374.x ), nodeVar374.y ), vec2( 0.00048828125 ), vec2( 0.99951171875 ) );
	nodeVar452 = ( vec2( ( nodeVar451.x + 2.0 ), ( nodeVar451.y + 1.0 ) ) / vec2( 3.0, 2.0 ) );
	nodeVar453 = nodeVar452;
	nodeVar455 = bool( nodeUniform63 );

	if ( nodeVar455 ) {

		nodeVar456 = nodeVar453;
		nodeVar454 = vec2( nodeVar456.x, 1.0 - nodeVar456.y );

	} else {

		nodeVar454 = nodeVar453;

	}

	nodeVar457 = textureLod( nodeUniform21, nodeVar454, 0.0 );
	nodeVar458 = nodeVar457;
	nodeVar459 = pow( max( dot( nodeVar378, vec3( 0.0, 0.0, -1.0 ) ), 0.0 ), 8.0 );
	nodeVar460 = vec3( 0.0, 0.0, 0.0 );
	nodeVar461 = 1000000.0;
	nodeVar462 = 1000000.0;

	if ( ( ( nodeVar413.w > 0.001 ) && ( nodeVar386 < nodeVar461 ) ) ) {

		nodeVar461 = nodeVar386;
		nodeVar460 = ( nodeVar413.xyz / vec3( max( nodeVar413.w, 0.001 ) ) );
		

	}


	if ( ( ( nodeVar413.w > 0.001 ) && ( nodeVar414 > 1e-8 ) ) ) {

		nodeVar462 = min( nodeVar462, nodeVar386 );
		

	}


	if ( ( ( nodeVar422.w > 0.001 ) && ( nodeVar387 < nodeVar461 ) ) ) {

		nodeVar461 = nodeVar387;
		nodeVar460 = ( nodeVar422.xyz / vec3( max( nodeVar422.w, 0.001 ) ) );
		

	}


	if ( ( ( nodeVar422.w > 0.001 ) && ( nodeVar423 > 1e-8 ) ) ) {

		nodeVar462 = min( nodeVar462, nodeVar387 );
		

	}


	if ( ( ( nodeVar431.w > 0.001 ) && ( nodeVar395 < nodeVar461 ) ) ) {

		nodeVar461 = nodeVar395;
		nodeVar460 = ( nodeVar431.xyz / vec3( max( nodeVar431.w, 0.001 ) ) );
		

	}


	if ( ( ( nodeVar431.w > 0.001 ) && ( nodeVar432 > 1e-8 ) ) ) {

		nodeVar462 = min( nodeVar462, nodeVar395 );
		

	}


	if ( ( ( nodeVar440.w > 0.001 ) && ( nodeVar396 < nodeVar461 ) ) ) {

		nodeVar461 = nodeVar396;
		nodeVar460 = ( nodeVar440.xyz / vec3( max( nodeVar440.w, 0.001 ) ) );
		

	}


	if ( ( ( nodeVar440.w > 0.001 ) && ( nodeVar441 > 1e-8 ) ) ) {

		nodeVar462 = min( nodeVar462, nodeVar396 );
		

	}


	if ( ( ( nodeVar449.w > 0.001 ) && ( nodeVar404 < nodeVar461 ) ) ) {

		nodeVar461 = nodeVar404;
		nodeVar460 = ( nodeVar449.xyz / vec3( max( nodeVar449.w, 0.001 ) ) );
		

	}


	if ( ( ( nodeVar449.w > 0.001 ) && ( nodeVar450 > 1e-8 ) ) ) {

		nodeVar462 = min( nodeVar462, nodeVar404 );
		

	}


	if ( ( ( nodeVar458.w > 0.001 ) && ( nodeVar405 < nodeVar461 ) ) ) {

		nodeVar461 = nodeVar405;
		nodeVar460 = ( nodeVar458.xyz / vec3( max( nodeVar458.w, 0.001 ) ) );
		

	}


	if ( ( ( nodeVar458.w > 0.001 ) && ( nodeVar459 > 1e-8 ) ) ) {

		nodeVar462 = min( nodeVar462, nodeVar405 );
		

	}

	nodeVar463 = vec3( 0.0, 0.0, 0.0 );
	nodeVar464 = 0.0;
	nodeVar465 = ( ( nodeVar414 * nodeVar413.w ) * exp( ( max( ( ( nodeVar386 - nodeVar462 ) - 4.0 ), 0.0 ) / -4.0 ) ) );
	nodeVar463 = ( nodeVar463 + ( ( nodeVar413.xyz / vec3( max( nodeVar413.w, 0.001 ) ) ) * vec3( nodeVar465 ) ) );
	nodeVar464 = ( nodeVar464 + nodeVar465 );
	nodeVar466 = ( ( nodeVar423 * nodeVar422.w ) * exp( ( max( ( ( nodeVar387 - nodeVar462 ) - 4.0 ), 0.0 ) / -4.0 ) ) );
	nodeVar463 = ( nodeVar463 + ( ( nodeVar422.xyz / vec3( max( nodeVar422.w, 0.001 ) ) ) * vec3( nodeVar466 ) ) );
	nodeVar464 = ( nodeVar464 + nodeVar466 );
	nodeVar467 = ( ( nodeVar432 * nodeVar431.w ) * exp( ( max( ( ( nodeVar395 - nodeVar462 ) - 4.0 ), 0.0 ) / -4.0 ) ) );
	nodeVar463 = ( nodeVar463 + ( ( nodeVar431.xyz / vec3( max( nodeVar431.w, 0.001 ) ) ) * vec3( nodeVar467 ) ) );
	nodeVar464 = ( nodeVar464 + nodeVar467 );
	nodeVar468 = ( ( nodeVar441 * nodeVar440.w ) * exp( ( max( ( ( nodeVar396 - nodeVar462 ) - 4.0 ), 0.0 ) / -4.0 ) ) );
	nodeVar463 = ( nodeVar463 + ( ( nodeVar440.xyz / vec3( max( nodeVar440.w, 0.001 ) ) ) * vec3( nodeVar468 ) ) );
	nodeVar464 = ( nodeVar464 + nodeVar468 );
	nodeVar469 = ( ( nodeVar450 * nodeVar449.w ) * exp( ( max( ( ( nodeVar404 - nodeVar462 ) - 4.0 ), 0.0 ) / -4.0 ) ) );
	nodeVar463 = ( nodeVar463 + ( ( nodeVar449.xyz / vec3( max( nodeVar449.w, 0.001 ) ) ) * vec3( nodeVar469 ) ) );
	nodeVar464 = ( nodeVar464 + nodeVar469 );
	nodeVar470 = ( ( nodeVar459 * nodeVar458.w ) * exp( ( max( ( ( nodeVar405 - nodeVar462 ) - 4.0 ), 0.0 ) / -4.0 ) ) );
	nodeVar463 = ( nodeVar463 + ( ( nodeVar458.xyz / vec3( max( nodeVar458.w, 0.001 ) ) ) * vec3( nodeVar470 ) ) );
	nodeVar464 = ( nodeVar464 + nodeVar470 );
	nodeVar463 = ( nodeVar463 / vec3( max( nodeVar464, 1e-8 ) ) );

	if ( ( nodeVar464 > 1e-8 ) ) {

		nodeVar471 = nodeVar463;

	} else {

		nodeVar471 = nodeVar460;

	}

	DiffuseColor = vec4( ( nodeVar471 * nodeUniform54 ), nodeVar373.w );
	DiffuseColor.w = ( DiffuseColor.w * nodeUniform64 );
	DiffuseColor.w = 1.0;
	gl_FragDepth = ImpostorDepth;
	Metalness = nodeUniform65;
	normalViewGeometry = normalize( v_normalViewGeometry );
	nodeVar472 = max( abs( dFdx( normalViewGeometry ) ), abs( dFdy( normalViewGeometry ) ) );
	Roughness = min( ( max( nodeUniform66, 0.0525 ) + max( max( nodeVar472.x, nodeVar472.y ), nodeVar472.z ) ), 1.0 );
	SpecularColor = vec3( 0.04, 0.04, 0.04 );
	SpecularColorBlended = mix( vec3( 0.04, 0.04, 0.04 ), DiffuseColor.xyz, Metalness );
	SpecularF90 = 1.0;
	DiffuseContribution = ( DiffuseColor.xyz * vec3( ( 1.0 - nodeUniform65 ) ) );
	nodeVar473 = max( vec4( DiffuseColor.xyz, DiffuseColor.w ), 0.0 );
	Output = nodeVar473;

	// result
	fragColor = nodeVar473;

}

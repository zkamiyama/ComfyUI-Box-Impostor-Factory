#version 300 es

// Three.js r186 - Node System


// extensions


// precision

precision highp float;
precision highp int;
precision highp sampler2D;
precision highp sampler3D;
precision highp samplerCube;
precision highp sampler2DArray;

precision highp usampler2D;
precision highp usampler3D;
precision highp usamplerCube;
precision highp usampler2DArray;

precision highp isampler2D;
precision highp isampler3D;
precision highp isamplerCube;
precision highp isampler2DArray;

precision highp sampler2DShadow;
precision highp sampler2DArrayShadow;
precision highp samplerCubeShadow;


// structs

layout( location = 0 ) out vec4 fragColor;



// uniforms

layout( std140 ) uniform render {
	vec2 nodeUniform1;
};

layout( std140 ) uniform object {
	uint nodeUniform2;
};
uniform sampler2D nodeUniform0;

// varyings


// vars
vec2 nodeVar0;
vec2 nodeVar1;
bool nodeVar2;
vec2 nodeVar3;
float nodeVar4;

// codes


void main() {

	// flow
	// code

	nodeVar0 = ( vec2( gl_FragCoord.xy.x, nodeUniform1.y - gl_FragCoord.xy.y ) / nodeUniform1 );
	nodeVar2 = bool( nodeUniform2 );

	if ( nodeVar2 ) {

		nodeVar3 = nodeVar0;
		nodeVar1 = vec2( nodeVar3.x, 1.0 - nodeVar3.y );

	} else {

		nodeVar1 = nodeVar0;

	}

	nodeVar4 = texture( nodeUniform0, nodeVar1 ).x;

	// result
	fragColor = vec4( nodeVar4, 0.0, 0.0, 1.0 );

}
